import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Worklist from '../../components/Worklist/Worklist';
import { getWorkListData } from '../../actions/worklistActions';
import Header from '../Header';
class WorklistContainer extends Component {

  constructor(props) {
    super(props);

    this.state = {
      searchOpenState: false
    };
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch(getWorkListData());
  }

  render() {
    let worklist = this.props.worklistData;
    worklist = (worklist === null || worklist === undefined) ? [] : worklist;

    return (
      <div className="worklist">
        <Header/>
        <Worklist
          worklist = { worklist }/>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    worklistData: state.worklistReducer.worklists,
    modal: state.notificationsReducer
  };
}

WorklistContainer.propTypes = {
  dispatch: PropTypes.func.isRequired,
  worklistData: PropTypes.array,
  modal: PropTypes.object
};

export default connect(mapStateToProps)(WorklistContainer);
