import React, { Component } from 'react';
import { connect } from 'react-redux';
import cssModules from 'react-css-modules';
import styles from './header.scss';

const logo = require('assets/images/logo.png');

@cssModules(styles)
class Header extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
  }

  componentWillUpdate() {
  }


  render() {
    return (
        <div>
          <div className="header-mark">
            <div className="logo leftGap">
              <img src={logo}/>
            </div>
            <div className="welcome rightGap">
              Welcome back,  Daeny888!
            </div>
          </div>
        </div>
    );
  }
}

Header.propTypes = {
  dispatch: React.PropTypes.func.isRequired,
};

function mapStateToProps(state) {
  return {
    state
  };
}

export default connect(mapStateToProps)(Header);
