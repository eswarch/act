import * as types from '../constants/actionTypes/worklist';

const items = [];
const initialState = {
  worklists: items,
  dataFilter: items,
  currentWorklist: items
};

export default function worklistReducer(state = initialState, action) {
  switch (action.type) {

    case types.WORKLIST_SUCCESS:
      return Object.assign({}, state, {
        worklists: action.res,
        dataFilter: action.res
      });

    case types.WORKLIST_ERROR:
      return Object.assign({}, state, {
        worklists: {},
        dataFilter: {}
      });
    default:
      return state;
  }
}
