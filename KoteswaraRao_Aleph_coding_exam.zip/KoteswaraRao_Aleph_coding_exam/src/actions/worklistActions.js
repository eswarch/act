import * as types from '../constants/actionTypes/worklist';
import { config } from '../config/config';
import request from 'superagent';

function worklistSuccess(res) {
  return { type: types.WORKLIST_SUCCESS, res };
}

function currentWorklistSuccess(res) {
  return { type: types.SET_CURRENT_WORKLIST_SUCCESS, res };
}

export function setCurrentWorkList(res) {
  return (dispatch) => {
    dispatch(currentWorklistSuccess(res));
  };
}

export function getWorkListData() {
  return (dispatch) => {
    request.get(config().baseUrl)
      .set({ 'Accept': 'application/json' })
      .end((err, res) => {
        if (err) {
          console.log(err);
        }
        const response = JSON.parse(res.text);
        dispatch(worklistSuccess(response.projects));
      });
  };
}

export function remove(d, k) {
  return (dispatch) => {
    d.recent.splice(k, 1);
    dispatch(worklistSuccess(d));
  };
}
