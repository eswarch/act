import React, { Component, PropTypes } from 'react';
import cssModules from 'react-css-modules';
import styles from './worklist.scss';
import { remove } from '../../actions/worklistActions';
import { connect } from 'react-redux';

@cssModules(styles)
class Worklist extends Component {
  constructor() {
    super();
    this.state = {
      currentList: '',
      listItems: '',
      flag: false
    };
  }

  removeItem(d, k) {
    const { dispatch } = this.props;
    dispatch(remove(d, k));
    this.setState({ flag: true });
    this.setState({ currentList: d });
  }

  render() {
    const obj = this.props.worklist;
    const isEmpty = (obj.length !== 0) ? obj.recent.length : [];
    const Empty = (isEmpty === undefined || isEmpty === 0) ? false : true;
    return (
      <div className="worklist-container">
        {
          (Empty && obj.recent) ?
          <div className="worklist-content">
            <div className="listProject">
              <h2 className="leftGap">List of Projects</h2>
            </div>
            <div className="mainContainer">
              A unique breed of engineers, craftsmen & <br/	>artists spread across Singapore, Indonesia, Malaysia, Thailand and Vietnam
            </div>
            {
              obj.recent.map(function showList(item, key) {
                return (
                  <div className="containers" key={ key }>
                    <div>
                      <div className="left">
                        <div className="imgC">
                          <img src={item.thumbnail}/>
                        </div>
                      </div>
                      <div className="left">
                        <div className="description colorBlue">
                          {item.title}
						</div>
						<div className="description colorGray">
						Rating : {item.rating}
						</div>
						<div className="description">
						<button className="viewMore" onClick={ this.removeItem.bind(this, obj, key) }> Remove </button>
						</div>
						</div>
					</div>
                  </div>
                );
              }, this)
            }
          </div>
         : ''
        }
      </div>
    );
  }
}

Worklist.propTypes = {
  dispatch: PropTypes.func.isRequired,
  worklist: PropTypes.object,
};

function mapStateToProps(state) {
  return {
    state
  };
}

export default connect(mapStateToProps)(Worklist);
